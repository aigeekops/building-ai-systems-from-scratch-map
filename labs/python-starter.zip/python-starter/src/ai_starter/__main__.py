"""Entry point: `python -m ai_starter`.

Without `LLM_API_KEY` this fails at startup with a Pydantic validation error.
That is the expected fast-fail behavior, not a bug.
"""

from __future__ import annotations

from .client import chat
from .config import Settings
from .schemas import Message


def main() -> None:
    settings = Settings()  # type: ignore[call-arg]
    reply = chat(settings, [Message(role="user", content="用一句话解释 GIL")])
    print(reply)


if __name__ == "__main__":
    main()