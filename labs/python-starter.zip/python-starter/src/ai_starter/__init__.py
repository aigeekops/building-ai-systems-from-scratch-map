"""Week 1 prerequisite: a minimal, testable LLM client."""

from .client import chat, chat_async
from .config import Settings
from .schemas import ChatRequest, ChatResponse, Message

__all__ = [
    "ChatRequest",
    "ChatResponse",
    "Message",
    "Settings",
    "chat",
    "chat_async",
]