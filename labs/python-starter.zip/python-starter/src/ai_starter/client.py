"""Minimal sync and async chat clients.

The `transport` parameter is the seam that makes this testable: tests inject
`httpx.MockTransport`, so the whole suite runs offline and costs nothing.
"""

from __future__ import annotations

import httpx

from .config import Settings
from .schemas import ChatRequest, ChatResponse, Message


def chat(
    settings: Settings,
    messages: list[Message],
    *,
    transport: httpx.BaseTransport | None = None,
) -> str:
    """Call the chat completions endpoint once and return the first message."""
    request = ChatRequest(model=settings.llm_model, messages=messages)
    with httpx.Client(
        base_url=settings.llm_base_url,
        headers={"Authorization": f"Bearer {settings.llm_api_key}"},
        timeout=settings.llm_timeout,
        transport=transport,
    ) as client:
        response = client.post("/chat/completions", json=request.model_dump())
        response.raise_for_status()

    data = ChatResponse.model_validate(response.json())
    return data.choices[0].message.content


async def chat_async(
    settings: Settings,
    messages: list[Message],
    *,
    transport: httpx.AsyncBaseTransport | None = None,
) -> str:
    """Async variant used by batch evaluation and Agent tool loops."""
    request = ChatRequest(model=settings.llm_model, messages=messages)
    async with httpx.AsyncClient(
        base_url=settings.llm_base_url,
        headers={"Authorization": f"Bearer {settings.llm_api_key}"},
        timeout=settings.llm_timeout,
        transport=transport,
    ) as client:
        response = await client.post("/chat/completions", json=request.model_dump())
        response.raise_for_status()

    data = ChatResponse.model_validate(response.json())
    return data.choices[0].message.content