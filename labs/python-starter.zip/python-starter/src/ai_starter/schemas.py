"""Boundary schemas for the chat completions API.

Pydantic models live at the system boundary: request payloads and responses
from an external model service. Internal data structures can stay lighter.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    model: str
    messages: list[Message]
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)


class Choice(BaseModel):
    message: Message


class ChatResponse(BaseModel):
    choices: list[Choice] = Field(min_length=1)
