"""Startup configuration.

`Settings()` fails fast when `LLM_API_KEY` is missing. That is intentional:
a service should not start with a half-configured client.
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    llm_api_key: str
    llm_base_url: str = "https://api.example.com/v1"
    llm_model: str = "gpt-4o-mini"
    llm_timeout: float = 15.0

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )