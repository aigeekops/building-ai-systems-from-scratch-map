"""Run a full client call without network access.

Usage:
    uv run python examples/offline_demo.py
"""

from __future__ import annotations

import httpx

from ai_starter.client import chat
from ai_starter.config import Settings
from ai_starter.schemas import Message


def main() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": "离线演示：GIL 是全局解释器锁。",
                        }
                    }
                ]
            },
        )

    settings = Settings(llm_api_key="demo-key")
    reply = chat(
        settings,
        [Message(role="user", content="用一句话解释 GIL")],
        transport=httpx.MockTransport(handler),
    )
    print(reply)


if __name__ == "__main__":
    main()