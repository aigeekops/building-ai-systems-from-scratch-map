from __future__ import annotations

from pathlib import Path

import httpx
import pytest
from pydantic import ValidationError

from ai_starter.__main__ import main
from ai_starter.client import chat, chat_async
from ai_starter.config import Settings
from ai_starter.schemas import Message


def make_mock_transport(payload: dict[str, object]) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=payload)

    return httpx.MockTransport(handler)


@pytest.mark.parametrize("expected_text", ["你好", "GIL 是全局解释器锁"])
def test_chat_success(expected_text: str) -> None:
    transport = make_mock_transport(
        {"choices": [{"message": {"role": "assistant", "content": expected_text}}]}
    )
    settings = Settings(llm_api_key="dummy-key")
    result = chat(settings, [Message(role="user", content="hi")], transport=transport)
    assert result == expected_text


@pytest.mark.parametrize("payload", [{"error": "unexpected payload"}, {"choices": []}])
def test_chat_invalid_schema_raises(payload: dict[str, object]) -> None:
    transport = make_mock_transport(payload)
    settings = Settings(llm_api_key="dummy-key")
    with pytest.raises(ValidationError):
        chat(settings, [Message(role="user", content="hi")], transport=transport)


def test_chat_timeout_raises() -> None:
    def timeout_handler(request: httpx.Request) -> httpx.Response:
        raise httpx.TimeoutException("Connection timed out")

    settings = Settings(llm_api_key="dummy-key")
    with pytest.raises(httpx.TimeoutException):
        chat(
            settings,
            [Message(role="user", content="hi")],
            transport=httpx.MockTransport(timeout_handler),
        )


@pytest.mark.asyncio
async def test_chat_async_success() -> None:
    transport = make_mock_transport(
        {"choices": [{"message": {"role": "assistant", "content": "异步响应成功"}}]}
    )
    settings = Settings(llm_api_key="dummy-key")
    result = await chat_async(
        settings,
        [Message(role="user", content="hi")],
        transport=transport,
    )
    assert result == "异步响应成功"


def test_missing_api_key_fails_at_startup(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("LLM_API_KEY", raising=False)

    with pytest.raises(ValidationError) as exc:
        main()

    assert exc.value.errors()[0]["loc"] == ("llm_api_key",)
