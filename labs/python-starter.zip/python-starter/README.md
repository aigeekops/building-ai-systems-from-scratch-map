# 01-python-starter：可测试的 AI 客户端骨架

第 1 周的前置代码。目标不是写一个功能完整的 SDK，而是把配置校验、边界解析、失败路径和离线测试四件事变成默认动作，作为后面 `03-mini-autograd` 之前的基础工程模板。

## 这一单元解决什么问题

用一个最小可运行的 LLM 客户端，把 AI 工程里最容易出问题的四层一次定下来：启动期配置校验、跨系统边界的 Pydantic 解析、HTTP 超时与错误传播、以及不依赖网络的 MockTransport 测试。跑完这一单元，后面写训练脚本、RAG 或 Agent 时，工程骨架不需要重新搭。

## 前置要求

- Python 3.10 或更新版本
- 推荐安装 `uv`；没有 `uv` 也可以用 `venv` + `pip`
- 不需要 API key，不需要 GPU，不需要外网。所有测试都通过 `httpx.MockTransport` 离线运行

## 快速开始

推荐用 `uv`：

```bash
cd units/00-prerequisites/01-python-starter
uv sync --locked --extra dev
uv run --no-sync pytest -q
uv run --no-sync ruff check .
uv run --no-sync mypy src
uv run --no-sync python examples/offline_demo.py
```

没有 `uv` 时：

```bash
cd units/00-prerequisites/01-python-starter
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
pytest -q
python examples/offline_demo.py
```

## 预期输出

```text
$ uv run --no-sync pytest -q
.......                                                                  [100%]
7 passed

$ uv run --no-sync ruff check .
All checks passed!

$ uv run --no-sync mypy src
Success: no issues found in 5 source files

$ uv run --no-sync python examples/offline_demo.py
离线演示：GIL 是全局解释器锁。
```

这组输出是在 Python 3.12.16 上实际运行的结果；测试不发起任何网络请求，换一台机器也应当得到同样的 7 个通过。

## 结构导览

```text
01-python-starter/
├── README.md
├── pyproject.toml
├── src/ai_starter/
│   ├── __init__.py     # 包入口，re-export 公共 API
│   ├── config.py       # 启动期配置校验
│   ├── schemas.py      # 请求与响应的 Pydantic 边界
│   ├── client.py       # 同步/异步客户端，transport 可注入
│   └── __main__.py     # python -m ai_starter 入口
├── tests/test_client.py
├── examples/offline_demo.py
└── docs/notes.md
```

建议阅读顺序：`config.py` → `schemas.py` → `client.py` → `tests/test_client.py`。先看配置和边界，再看请求怎么发、错误怎么传、测试怎么拦截。

## 已知限制

- 只实现一次非流式请求，没有重试、退避、限流、流式响应和成本统计。
- 响应缺少 `choices` 或列表为空时会抛出 Pydantic `ValidationError`。调用方可按需转换为服务自己的异常。
- 没有真实 API key 的联调路径；这一单元刻意只验证离线主干。
- `Settings` 使用 `pydantic-settings`，`.env` 只在本地生效，`.env` 不进 git。
- 依赖版本随安装时间变化；锁文件与测试版本见 `docs/notes.md`。

## 对应文章

第 1 周实战篇 [《20 分钟搭出生产级 AI 工程骨架：uv、ruff、pydantic 与异步测试》](https://mp.weixin.qq.com/s?__biz=MzYyNDcwNzQzMg==&mid=2247484975&idx=1&sn=a8c9a010075214cd001a269d55f9d2fe&chksm=f0321428c7459d3e93bce70ff57c8bc8311e69711019354d5e071055724b2c1afac4872ac49a#rd)。
