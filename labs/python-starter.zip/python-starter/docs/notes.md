# 设计笔记

## 为什么用 `src` 布局

把包放进 `src/ai_starter/`，而不是仓库根目录，可以防止「在当前目录下运行 Python 时意外导入未安装的本地半成品」。所有导入都必须经过 `pip install -e .` 或 `uv run`，开发与安装后的行为一致。

## 为什么把 `transport` 暴露成参数

`chat(..., transport=...)` 是这一单元最重要的设计点。生产代码默认走真实 HTTP；测试注入 `httpx.MockTransport`，整个测试套件零网络、零花费、毫秒级完成。没有这个缝，测试就只能打真实接口，或者把客户端逻辑 mock 掉。

## 为什么用 Pydantic 守边界

内部数据流可以用轻量 dataclass；但只要跨出进程边界（请求体、响应体、工具参数），就用 Pydantic 校验。必填字段缺失、字段类型非法或 `choices` 为空时，在解析响应处抛出 `ValidationError`。模型服务额外返回的字段沿用 Pydantic 默认行为，由示例忽略。

## 为什么同时保留同步和异步版本

同步版本适合脚本和 CLI；异步版本适合批量评估、并发 Agent 工具调用。两者共用同一套 schema 和配置，区别只在 `httpx.Client` 与 `httpx.AsyncClient`。

## 已知限制

- 没有重试和退避；429/500 由调用方处理。
- 没有流式响应；`stream=True` 的链路留给后面的服务化单元。
- 没有真实 API 联调；`.env` 只用于本地手工验证。
- 没有打包发布配置；这一单元只要求可安装、可测试。

## 版本与硬件

实测环境：Python 3.12.16（uv 管理），macOS，CPU only。实测版本：httpx 0.28.1、pydantic 2.14.3、pydantic-settings 2.16.3、pytest 9.2.0、pytest-asyncio 1.5.0、ruff 0.17.5、mypy 2.4.1。依赖版本以 `uv.lock` 为准；换机器复现时先跑 `uv sync --locked --extra dev`，再跑 `uv run --no-sync pytest -q`。

## 与文章的关系

文章是覆盖到「能读源码」的语法手册；这一单元只落地其中的工程部分：解释器隔离、配置校验、边界解析、异步 IO 与离线测试。形状断言、生成器等语言层面的内容在后续 `03-mini-autograd` 与 `04-mini-mlp` 中继续使用。
